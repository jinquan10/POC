// A ring buffer backed by an array.

CappedArray = function(maxSize) {
    this.maxSize = maxSize;
    this.contents = new Array(maxSize);
    this.cursor = 0;
    this.numElements = 0;

    this.add = function(elem) {
        if (elem == undefined) {
            return;
        }
        this.contents[this.cursor++] = elem;
        if (this.cursor > (this.maxSize - 1)) {
            this.cursor = 0;
        }
        this.numElements++;
    };

    this.asArray = function() {
        var returnArray = new Array(this.maxSize);
        var returnIndex = 0;
        var index;
        var start = this.cursor;
        for (index = start; index < this.maxSize; index ++){
            if (this.contents[index] != undefined)
                returnArray[returnIndex++] = this.contents[index];
        }
        for (index = 0; index < this.cursor; index++) {
            returnArray[returnIndex++] = this.contents[index];
        }
        return returnArray;
    };
    
    this.getNumElements = function() {
        return this.numElements;
    };
};
