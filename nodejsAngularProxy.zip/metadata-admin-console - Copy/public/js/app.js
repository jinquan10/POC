'use strict';

/* App Module */

var metadataApp = angular.module('metadataApp', [
  'ngRoute',
  'metadataControllers',
  'metadataServices',
  'metadataFilters'
]);

metadataApp.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
      when('/metadata', {
        templateUrl: 'partials/metadata.html',
        controller: 'metadataController'
      }).
      otherwise({
        redirectTo: '/metadata'
      });
  }]);