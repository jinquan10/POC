'use strict';

/* Controllers */

var metadataControllers = angular.module('metadataControllers', []);

metadataControllers.controller('metadataController', [ '$scope', '$filter', 'Orgs', 'OrgSchema', 'Games', 'Game', 'Seasons', function($scope, $filter, Orgs, OrgSchema, Games, Game, Seasons) {

    $scope.orgs = null;
    $scope.formattedOrgs = null; /* [{name:"foo", id:1, fields: [{displayOrder: 1, field: {name:"foo", description:"bar", createDate:"asfafd"}}]}] */
    $scope.orgSchema = OrgSchema.query(function() {
        $scope.orgs = getOrgs();
    });

    $scope.getKeyFromField = function(field) {
        var theField = field['field'];

        for ( var key in theField) {
            return key;
        }
    }

    $scope.parseInputNgShow = function(orgId, key) {
        return 'form' + orgId + '.org' + key + '.$error.required';
    }
    
    function getOrgs(){
        return Orgs.query(function() {
            $scope.formattedOrgs = formatOrgsForDisplayOrder($scope.orgs);
        });
    }

    function isPromiseOrResolved(key) {
        return key == '$promise' || key == '$resolved';
    }

    function formatOrgsForDisplayOrder(orgs) {
        var formattedOrgs = [];
        var orgSchema = $scope.orgSchema;

        angular.forEach(orgs, function(value, orgKey) {
            if (!isPromiseOrResolved(orgKey)) {

                var formattedOrg = {};

                formattedOrg['name'] = orgs[orgKey].name;
                formattedOrg['id'] = orgs[orgKey].id;
                formattedOrg['fields'] = [];

                var fields = formattedOrg['fields'];
                var org = orgs[orgKey];

                angular.forEach(org, function(value, fieldKey) {
                    if (!isPromiseOrResolved(fieldKey)) {
                        var fieldContainer = {};
                        var field = {};

                        field[fieldKey] = org[fieldKey];

                        fieldContainer['field'] = field;
                        fieldContainer['displayOrder'] = orgSchema[fieldKey].displayOrder;

                        fields.push(fieldContainer);
                    }
                })
                formattedOrgs.push(formattedOrg);
            }
        });

        return formattedOrgs;
    }

    // $scope.orgsSortOrder = generateSortOrder($scope.orgSchema);
    // $scope.object2ArrayForOrderBy = $filter('object2ArrayForOrderBy');
    // function generateSortOrder(schema) {
    // var sortOrder = {};
    //
    // var editableKeysInOrder = [];
    // var nonEditableKeysInOrder = [];
    //
    // angular.forEach(schema, function(value, key) {
    // if (!value.readOnly) {
    // editableKeysInOrder.push(key);
    // } else {
    // nonEditableKeysInOrder.push(key);
    // }
    // });
    //
    // editableKeysInOrder.sort();
    // nonEditableKeysInOrder.sort();
    //
    // var order = 1;
    //
    // angular.forEach(editableKeysInOrder, function(value, key) {
    // sortOrder[value] = order;
    // order++;
    // });
    //
    // angular.forEach(nonEditableKeysInOrder, function(value, key) {
    // sortOrder[value] = order;
    // order++;
    // });
    //
    // return sortOrder;
    // }

    $scope.showMetadataDeletionModal = function(id, metadataCategory, metadataName, deletionFunction) {
        $scope.currentMetadataCategory = metadataCategory;
        $scope.currentMetadataName = metadataName;

        $scope.deleteMetadata = function() {
            deletionFunction(id);
        };
    };

    $scope.createOrg = function(org) {
        Orgs.create(org, function() {
            $scope.orgs = getOrgs();
        });
    };

    // - Refresh the modal, assign create button to be to create org, populate
    // modal fields from schema
    $scope.createOrgModal = function() {
        $scope.createMetadataTitle = "Create Organization";

        if ($scope.orgSchema == null) {
            OrgSchema.query(function(schema) {
                $scope.metadataCreationModel = initCreationModel(schema);
            });
        } else {
            $scope.metadataCreationModel = initCreationModel($scope.orgSchema);
        }

        $scope.createMetadata = $scope.createOrg;
    };

    function initCreationModel(schema) {
        var model = {};

        angular.forEach(schema, function(value, key) {
            if (value.readOnly != true) {
                model[key] = "";
            }
        });

        return model;
    }

    $scope.updateOrg = function(org) {
        var updateFields = extractUpdateFields(org, $scope.orgSchema);

        var result = Orgs.update({
            id : org.id
        }, updateFields, function() {
            $scope.orgs[org.id] = result;
        });
    };

    function extractUpdateFields(model, schema) {
        var updateFields = {};

        angular.forEach(model, function(value, key) {
            if (!schema[key].readOnly) {
                updateFields[key] = value;
            }
        });

        return updateFields;
    }

    $scope.removeOrg = function(orgId) {
        Orgs.remove({
            id : orgId
        }, function() {
            $scope.orgs = getOrgs();
        });

        $("#gamesBtn").html("Games");
    };

    $scope.updateGame = function(game) {
        Game.update({
            id : game.id
        }, game);
    };

    $scope.loadSeasons = function(gameId) {
        $scope.seasons = Seasons.query({
            gameId : gameId
        });
    };

    $scope.loadGames = function(org) {
        $scope.games = Games.query({
            orgId : org.id
        });

        $("#gamesBtn").click();
        $("#gamesBtn").html(org.name);
    };

    $(".btn-group > .btn").click(function() {
        $(".btn-group > .btn").removeClass("active");
        $(this).addClass("active");
    });
} ]);