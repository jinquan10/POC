'use strict';

/* Filters */

var app = angular.module('metadataFilters', []).filter('object2ArrayForOrderBy', function($filter) {
    return function(object, sortOrder, schema) {
        var out = [];

        angular.forEach(object, function(value, key) {
            var obj = {};
            obj[key] = value;
            obj['order'] = sortOrder[key];
            out.push(obj);
        });

        var orderBy = $filter('orderBy');
        var orderByResult = orderBy(out, 'order', false);

        var result = [];

        for (var i = 0; i < orderByResult.length; i++) {
            var prop = orderByResult[i];
            
            for (var v in prop) {
                if (schema.hasOwnProperty(v)) {
                    var o = {};
                    o[v] = prop[v];
                    result.push(o);
                }
            }
        }
        
        return result;
    }
});