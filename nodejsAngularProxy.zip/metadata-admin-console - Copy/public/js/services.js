'use strict';

/* Services */

var metadataServices = angular.module('metadataServices', [ 'ngResource' ]);

metadataServices.factory('OrgSchema', [ '$resource', function($resource) {
    return $resource('http://localhost:3000/fuse/apis/fantasy/organizations/schema', {}, {
        query : {
            method : 'GET'
        }
    });
} ]);

metadataServices.factory('Orgs', [ '$resource', function($resource) {
    return $resource('http://localhost:3000/fuse/apis/fantasy/organizations/:id', {}, {
        query : {
            method : 'GET'
        },
        create : {
            method : 'POST'
        },
        update : {
            method : 'PUT'
        },
        remove : {
            method : 'DELETE'
        }
    });
} ]);

metadataServices.factory('Games', [ '$resource', function($resource) {
    return $resource('http://localhost:3000/fuse/apis/fantasy/organizations/:orgId/games', {}, {
        query : {
            method : 'GET',
            isArray : true
        }
    });
} ]);

metadataServices.factory('Game', [ '$resource', function($resource) {
    return $resource('http://localhost:3000/fuse/apis/fantasy/games/:id', {}, {
        update : {
            method : 'PUT'
        }
    });
} ]);

metadataServices.factory('Seasons', [ '$resource', function($resource) {
    return $resource('http://localhost:3000/fuse/apis/fantasy/games/:gameId/seasons', {}, {
        query : {
            method : 'GET',
            isArray : true
        }
    });
} ]);