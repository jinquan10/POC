var httpProxy = require('http-proxy');
var express = require('express'), path = require('path');
var app = express();

app.use(express.static(path.join(__dirname, 'public')));

var server = app.listen(3000, function() {
});

var proxy = httpProxy.createProxyServer({});

app.all('/fuse/*', function (request, response) {
    proxy.web(request, response, {
        target: 'http://localhost:7950'
    });	
});